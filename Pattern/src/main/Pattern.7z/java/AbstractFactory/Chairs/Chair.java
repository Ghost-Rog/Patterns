package AbstractFactory.Chairs;

public abstract class Chair {

    protected String name;

    public Chair(String name) {
        this.name = name;
    }
}
