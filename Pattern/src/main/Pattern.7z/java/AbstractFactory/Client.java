package AbstractFactory;

import AbstractFactory.Chairs.Chair;
import AbstractFactory.Factorys.AbstractFactory;
import AbstractFactory.Tables.Table;

public class Client {

    private AbstractFactory factory;

    public Client(AbstractFactory factory) {
        this.factory = factory;
    }

    public void setFactory(AbstractFactory factory) {
        this.factory = factory;
    }

    public void construct() {
        Table table = factory.createProductTable();
        Chair chair = factory.createProductChair();
        System.out.println(table);
        System.out.println(chair);
    }

}
