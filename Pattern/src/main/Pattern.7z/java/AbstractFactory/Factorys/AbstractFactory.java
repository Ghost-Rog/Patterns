package AbstractFactory.Factorys;

import AbstractFactory.Chairs.Chair;
import AbstractFactory.Tables.Table;

public interface AbstractFactory {

    Chair createProductChair();
    Table createProductTable();

}
