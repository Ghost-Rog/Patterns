package AbstractFactory.Factorys;

import AbstractFactory.Chairs.BraveChair;
import AbstractFactory.Chairs.Chair;
import AbstractFactory.Chairs.DecorChair;
import AbstractFactory.Tables.BraveTable;
import AbstractFactory.Tables.DecorTable;
import AbstractFactory.Tables.Table;

public class BraveFactory implements AbstractFactory{
    @Override
    public Chair createProductChair() {
        return new BraveChair("стул2");
    }

    @Override
    public Table createProductTable() {
        return new BraveTable("стол2");
    }
}
