package AbstractFactory.Factorys;

import AbstractFactory.Chairs.Chair;
import AbstractFactory.Chairs.DecorChair;
import AbstractFactory.Chairs.ModernChair;
import AbstractFactory.Tables.DecorTable;
import AbstractFactory.Tables.ModernTable;
import AbstractFactory.Tables.Table;

public class ModernFactory implements AbstractFactory{

    public Chair createProductChair() {
        return new ModernChair("стул3");
    }

    public Table createProductTable() {
        return new ModernTable("стол3");
    }
}
