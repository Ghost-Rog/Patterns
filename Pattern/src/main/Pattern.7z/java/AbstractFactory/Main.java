package AbstractFactory;

import AbstractFactory.Factorys.BraveFactory;
import AbstractFactory.Factorys.DecorFactory;
import AbstractFactory.Factorys.ModernFactory;

public class Main {
    public static void main(String[] args) {

        Client client = new Client(new DecorFactory());
        client.construct();
        client.setFactory(new ModernFactory());
        client.construct();
        client.setFactory(new BraveFactory());
        client.construct();


    }
}
