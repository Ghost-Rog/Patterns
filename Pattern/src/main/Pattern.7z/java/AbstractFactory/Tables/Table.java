package AbstractFactory.Tables;


public abstract class Table {

    protected String name;

    public Table(String name) {
        this.name = name;
    }
}
