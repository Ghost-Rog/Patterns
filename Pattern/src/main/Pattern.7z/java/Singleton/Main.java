package Singleton;

public class Main {
    public static void main(String[] args) {

        Db.getInstance();
        Db.getInstance();


    }
}
